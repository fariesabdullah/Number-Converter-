-The app is already pre-installed in the folder. Extract from the zipfile to use.
-The app can be sent to desktop for shortcut
-There is no Malware/Virus in this zipfile, however, most laptop will ask permission to run the app first because the laptop security. 

-If there is a bug, feel free to email to: faries.abdullah@mquestsys.com

Current version : 2.2 